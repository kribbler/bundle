<?php
class WPBakeryShortCode_VC_Posts_slider extends WPBakeryShortCode {
}