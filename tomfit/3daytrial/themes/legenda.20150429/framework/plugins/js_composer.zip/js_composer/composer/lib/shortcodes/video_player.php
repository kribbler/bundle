<?php
class WPBakeryShortCode_VC_Video extends WPBakeryShortCode {
}