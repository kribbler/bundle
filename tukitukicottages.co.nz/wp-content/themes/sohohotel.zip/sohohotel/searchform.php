<form method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="page-content search">
	<input type="text" onblur="if(this.value=='')this.value='Search...';" onfocus="if(this.value=='Search...')this.value='';" value="Search..." name="s" id="widget-search" class="text-input" />
</form>