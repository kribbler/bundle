If a translation file for your language does not come bundled with this plugin, then check out this URL:

http://codex.wordpress.org/Translating_WordPress

It will walk you through how to translate the plugin using the provided template file, "_vipers-video-quicktags-template.po".

Once you're done and have the plugin translated, please send me your translation file so that I can
bundle it with my plugin: http://www.viper007bond.com/contact/

I will give you credit and it will help others who speak your language.

Thanks!

-Viper