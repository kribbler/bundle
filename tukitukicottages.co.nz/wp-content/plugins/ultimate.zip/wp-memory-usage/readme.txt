=== WP-Memory-Usage ===
Contributors: alexrabe
Donate link: http://alexrabe.boelinger.com/donation/
Tags: memory, admin, nextgen-gallery, php, memory-limit
Requires at least: 2.7
Tested up to: 3.2
Stable tag: trunk

Show up the PHP version, memory limit and current memory usage in the dashboard and admin footer

== Description ==

Show up the PHP version, memory limit and current memory usage in the dashboard and admin footer. You can now simple measure the requirements of your plugins and language files.
<a href="http://alexrabe.boelinger.com/2009/06/14/dear-hoster-we-need-more-memory/" title="Demonstration page">Here my blog post about the plugin</a>

== Credits ==

Copyright 2009-2011 by Alex Rabe

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

== Screenshots ==

1. Screenshot Dashboard

1. Screenshot Admin footer

