<?php
/*Lastest fr_FR translation for 120 - 070928ms*/
$post_notification_strings = array(
	'error' => 'Erreur',
	'already_subscribed' => 'Vous êtes déjà abonné!',
	'activation_faild' => 'Problème enregistrement',
	'address_not_in_database' => 'Votre courriel est absent de la base.',
	'sign_up_again'=>'SVP recommencez.',
	'deaktivated' => 'Désabonné',
	'no_longer_activated' => 'Le courriel @@addr est supprimé de @@blogname.',
	'check_email' => 'SVP entrez une adresse courriel valide.',
	'wrong_captcha' => 'Malheureusement le "mot" Captcha est erroné.',
	'registration_successful' => 'Enregistrement réussi',
	'activated' => 'Activé correctement',
	'all' => 'TOUT',
	'saved' => 'Les réglages sont sauvés.',
	'unsubscribe_mail' => 'Vous avez reçu un courriel avec un lien de désactivation.',
	)
?>