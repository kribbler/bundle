ALTER TABLE Tyres
MODIFY COLUMN TreadPattern varchar(20);