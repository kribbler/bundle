ALTER TABLE Quantity ADD COLUMN UpdatedDate     datetime    NULL;
ALTER TABLE Prices ADD COLUMN UpdatedDate     datetime    NULL;