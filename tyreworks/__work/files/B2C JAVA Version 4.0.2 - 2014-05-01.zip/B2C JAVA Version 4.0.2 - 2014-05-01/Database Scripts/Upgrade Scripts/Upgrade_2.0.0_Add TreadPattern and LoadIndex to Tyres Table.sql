ALTER TABLE Tyres ADD COLUMN TreadPattern varchar(10) default NULL;
ALTER TABLE Tyres ADD COLUMN LoadIndex varchar(8) default NULL;